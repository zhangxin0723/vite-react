var baseHref = window.location.protocol + "//" + window.location.host;
var pt = "ws";
if (window.location.protocol === "https:")  pt = "wss";

var globalConstant = {
  webTitle: "Vite React Admin",
};
